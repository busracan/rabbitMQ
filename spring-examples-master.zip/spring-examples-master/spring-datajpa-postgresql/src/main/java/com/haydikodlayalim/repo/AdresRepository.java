package com.haydikodlayalim.repo;

import com.haydikodlayalim.entity.Adres;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdresRepository extends JpaRepository<Adres, Long> {

}
