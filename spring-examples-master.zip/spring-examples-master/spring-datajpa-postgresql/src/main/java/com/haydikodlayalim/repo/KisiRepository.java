package com.haydikodlayalim.repo;

import com.haydikodlayalim.entity.Kisi;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KisiRepository extends JpaRepository<Kisi, Long> {
}
