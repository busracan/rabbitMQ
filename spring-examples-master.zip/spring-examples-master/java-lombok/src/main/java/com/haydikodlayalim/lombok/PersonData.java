package com.haydikodlayalim.lombok;

import lombok.Data;

@Data
public class PersonData {
    private Long id;
    private String name;
    private String surname;
}
