insert into users (firstname, username, lastname) values ('Test', 'testuser', 'Test Lastname');
insert into users (firstname, username, lastname) values ('Test2', 'testuser2', 'Test Lastname2');